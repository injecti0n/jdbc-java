package be.infernalwhale;

import javax.swing.plaf.nimbus.State;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BeerDao {
    public List<Beer> findBeersByNameContaining(String nameSubString) throws SQLException {
        String sql = String.format("SELECT * FROM beers WHERE name LIKE '%%%s%%'", nameSubString);

        ResultSet rs = sendSelectSQLtoServer(sql);
        List<Beer> resultList = parseResultSetToBeerList(rs);

        return resultList;
    }


    public List<Beer> findBeersByAlcohol(Float min, Float max) throws SQLException {
        String sql = String.format("SELECT * FROM beers WHERE alcohol BETWEEN %.2f AND %.2f", min, max);

        ResultSet rs = sendSelectSQLtoServer(sql);
        List<Beer> resultList = parseResultSetToBeerList(rs);

        return resultList;
    }

    private List<Beer> parseResultSetToBeerList(ResultSet rs) throws SQLException {
        List<Beer> resultList = new ArrayList<>();

        while (rs.next()) {
            Beer beer = new Beer();
            beer.setName(rs.getString("name"));
            beer.setAlcohol(rs.getFloat("alcohol"));
            beer.setPrijs(rs.getFloat("price"));
            beer.setStock(rs.getInt("stock"));
            resultList.add(beer);
        }

        return resultList;
    }

    private ResultSet sendSelectSQLtoServer(String sql) throws SQLException {
        Connection connection = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/beersDB",
                "root",
                "intec-123"
        );
        Statement statement = connection.createStatement();
        return statement.executeQuery(sql);
    }
}
