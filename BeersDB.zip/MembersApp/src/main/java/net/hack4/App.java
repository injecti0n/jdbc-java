package net.hack4;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.UIManager;
import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;

public class App {

	private JFrame frmIntecbrusselBeersdb;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_3;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					App window = new App();
					window.frmIntecbrusselBeersdb.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public App() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmIntecbrusselBeersdb = new JFrame();
		frmIntecbrusselBeersdb.setTitle("INTECBRUSSEL | BeersDB Project | Developed by h4x0r");
		frmIntecbrusselBeersdb.setBounds(100, 100, 798, 537);
		frmIntecbrusselBeersdb.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmIntecbrusselBeersdb.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "INTECBRUSSEL | BeersDB Managemenet", TitledBorder.CENTER, TitledBorder.TOP, null, null));
		panel.setBounds(10, 11, 220, 235);
		frmIntecbrusselBeersdb.getContentPane().add(panel);
		panel.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(66, 78, 126, 20);
		panel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(66, 101, 126, 20);
		panel.add(textField_1);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(66, 125, 126, 20);
		panel.add(textField_3);
		
		JLabel lblNewLabel = new JLabel("Name");
		lblNewLabel.setBounds(10, 78, 46, 14);
		panel.add(lblNewLabel);
		
		JLabel lblAlcohol = new JLabel("Alcohol");
		lblAlcohol.setBounds(10, 101, 46, 14);
		panel.add(lblAlcohol);
		
		JLabel lblStock = new JLabel("Stock");
		lblStock.setBounds(10, 125, 46, 14);
		panel.add(lblStock);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "Result", TitledBorder.CENTER, TitledBorder.TOP, null, null));
		panel_1.setBounds(240, 11, 532, 235);
		frmIntecbrusselBeersdb.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(10, 11, 514, 213);
		panel_1.add(textArea);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
			},
			new String[] {
				"Id", "Name", "BrewerId", "Stock", "Price", "Stock", "Version"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		table.setBounds(10, 257, 762, 160);
		frmIntecbrusselBeersdb.getContentPane().add(table);
		
		JButton btnAdd = new JButton("ADD");
		btnAdd.setBounds(61, 437, 122, 37);
		frmIntecbrusselBeersdb.getContentPane().add(btnAdd);
		
		JButton btnDelete = new JButton("DELETE");
		btnDelete.setBounds(193, 437, 122, 37);
		frmIntecbrusselBeersdb.getContentPane().add(btnDelete);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.setBounds(325, 437, 122, 37);
		frmIntecbrusselBeersdb.getContentPane().add(btnUpdate);
		
		JButton btnShowInfo = new JButton("SHOW INFO");
		btnShowInfo.setBounds(457, 437, 122, 37);
		frmIntecbrusselBeersdb.getContentPane().add(btnShowInfo);
		
		JButton btnExit = new JButton("EXIT");
		btnExit.setBounds(589, 437, 122, 37);
		frmIntecbrusselBeersdb.getContentPane().add(btnExit);
	}
}
