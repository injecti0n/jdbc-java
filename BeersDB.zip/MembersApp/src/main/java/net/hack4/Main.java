package net.hack4;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Gelieve een min alcohol gehalte in te geven:");
        Float min = input.nextFloat();

        System.out.println("Gelieve een max alcohol gehalte in te geven");
        Float max = input.nextFloat();

        BeerDao beerDao = new BeerDao();

        try {
            List<Beer> beers = beerDao.findBeersByAlcohol(min, max);
            beers.stream().forEach(System.out::println);
        } catch (SQLException e) {
            System.out.println("There was a problem with building your db connection");
        }
    }
}
